[
{"codes":[0],"description":"ice not building up"},
{"codes":[1],"description":"ice building up slowly"},
{"codes":[2],"description":"ice building up rapidly"},
{"codes":[3],"description":"ice melting or breaking up slowly"},
{"codes":[4],"description":"ice melting or breaking up rapidly"}
]
