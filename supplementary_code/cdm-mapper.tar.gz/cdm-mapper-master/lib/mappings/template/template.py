#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Apr  3 10:31:18 2019
@author: iregon
"""

    
class mapping_functions():
    def __init__(self, atts):
        self.atts = atts
